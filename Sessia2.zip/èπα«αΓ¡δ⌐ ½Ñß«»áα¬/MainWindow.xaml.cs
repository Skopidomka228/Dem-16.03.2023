﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Курортный_лесопарк
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnauthorizationClick(object sender, RoutedEventArgs e)
        {
            {
                try
                {

                    if (txbLogin.Text != string.Empty && psbPassword.Password != string.Empty)
                    {

                        var CurrentUser = DataBase.AppData.db.Сотрудник.FirstOrDefault(u => u.Логин == txbLogin.Text && u.Пароль == psbPassword.Password);

                        if (CurrentUser != null)
                        {
                            Main.Navigate(new Menu());
                        }
                        else
                        {
                            MessageBox.Show("Неправильное имя пользователя или пароль!", "Ошибка");
                        }
                    }
                    else
                    {
                        throw new Exception("Заполните все поля!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"{ex.Message}");
                }
            }
        }
    }
}
