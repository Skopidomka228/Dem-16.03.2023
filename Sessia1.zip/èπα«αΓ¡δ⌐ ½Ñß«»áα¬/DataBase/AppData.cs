﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Курортный_лесопарк.DataBase
{
    public static class AppData
    {
        public static Курортный_лесопаркEntities db = new Курортный_лесопаркEntities();
    }
}
